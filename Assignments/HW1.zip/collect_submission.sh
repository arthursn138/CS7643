rm -f assignment_1_submission.zip
zip -r assignment_1_submission.zip configs models optimizer *.py

