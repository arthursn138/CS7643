import numpy as np

# Q1: Create a zero vector of size 10
def q1():
    x = None
    return x

# Q2: Create an int64 zero matrix of size (10, 10) with the diagonal values set to -1
def q2():
    x = None
    return x

# Q3: Create an 8x8 matrix and fill it with a checkerboard pattern with 0s and 1s (starting with 0 at [0, 0])
def q3():
    x = None
    return x

# Q4: Randomly place five 1s in a given zero matrix
def q4(x):
    return x

# Q5: Given a tensor (image) of dimensions of (H, W, C), return the same tensor as (C, H, W)
def q5(im):
    return im

# Q6: Given a tensor (image) of dimension (C, H, W) with channel ordering of RGB, swap the channel ordering to BGR
def q6(im):
    return im

# Q7: Given a 1D array, negate (i.e., multiply by -1) all elements in indices [3, 8], in-place
def q7(x):
    return x

# Q8: Convert a float64 array to a uint8 array
def q8(x):
    return x

# Q9: Subtract the mean of each row in the matrix (i.e., subtract the mean of row1 from each element in row1 and continue)
def q9(x):
    return x

# Q10: The same as Q9, but without a loop (if you used a loop)
def q10(x):
    return x

# Q11: Sort the rows of a matrix by the matrix's second column
def q11(x):
    return x

# Q12: Convert an array of size 5 with N=10 (all are values within [0, 9]) to a one-hot encoding matrix as described in the notebook
def q12(x):
    return x

# Q13: In a single expression, multiply the n-th row of a given matrix with the n-th element in a given vector.
def q13(x, y):
    return x

# Q14: Without using `np.pad`, pad an array with a border of zeros
def q14(x):
    return x

