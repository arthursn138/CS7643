# Deep Learning HW0

This homework is simply designed to test your numpy and documentation-searching skills. If you struggle with this assignment, it is wise to brush up on your numpy/python knowledge.

Fill out the functions in `hw0.py`. We have provided `hw0.ipynb` for testing purposes.

After finishing, submit `hw0.py` to the HW0 assignment on Gradescope.